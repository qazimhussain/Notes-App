const mongoose=require('mongoose')
const notesSchema=mongoose.Schema({
    title:String,
    desc:String
})

module.exports=mongoose.model('notes',notesSchema)