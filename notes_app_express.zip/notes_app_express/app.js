const express=require('express')

const app=express()
app.use(express.urlencoded({extended:false}))

const frontendRouter=require('./routers/frontendRouter')

const session=require('express-session')
const mongoose=require('mongoose')

mongoose.connect('mongodb://127.0.0.1:27017/notesbase',()=>{
    console.log("connecting to notesbase")
})

app.use(session(
    {
        secret:'notes',
        saveUninitialized:false,
        resave:false

    }
))


// console.log(app)


app.use(frontendRouter)

app.set('view engine','ejs')

app.use(express.static('public'))

app.listen(5000,()=>{
    console.log("port running on 5000")
})