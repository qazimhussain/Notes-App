const router=require('express').Router()

const Notes=require('../models/notes')

const bcrypt=require('bcrypt')

const User=require('../models/user')



// middleware function

function checklogin(req,res,next){
    if(req.session.isAuth)
    {
        next()
    }
    else{
        res.redirect('/login')
    }
}



router.get('/',checklogin,async(req,res)=>{

   const notes_record=await Notes.find()



   res.render('index',{notes_record})


})


// insert

router.get('/add_notes',checklogin,(req,res)=>{
    res.render('add_notes')
})

router.post('/post_add_record',checklogin,async(req,res)=>{

    
      const title=req.body.title.trim()
      const desc=req.body.desc.trim()

      if(!(title.length==0 || desc.length==0))
      {

        const notes_record= new Notes({
            title:title,
            desc:desc
          })
    
          notes_record.save()
    
          res.redirect('/')
      }

      else{
        res.redirect('/add_notes')
      }

    
})

// delete

router.get('/delete_notes/:id',checklogin,async(req,res)=>{

    const id=req.params.id

   await Notes.findByIdAndDelete(id)

    res.redirect('/')

})

router.get('/view_notes/:id',checklogin,async(req,res)=>{

    const id=req.params.id

    const notes= await Notes.findById(id)

    console.log(notes)

    res.render('notes_view',{notes})
})

router.get('/update_notes/:id',checklogin,async(req,res)=>{

    const id=req.params.id

    const notes=await Notes.findById(id)


    res.render('update_notes',{notes})
})


router.post('/post_update_record/:id',checklogin,async(req,res)=>{

    const title=req.body.title.trim()
    const id=req.params.id

    const desc=req.body.desc.trim()

    if(!(title.length==0 || desc.length==0))
    {

    
        await Notes.findByIdAndUpdate(id,{
            title:title,
            desc:desc
        })
  
        res.redirect('/')
    }

    else{
      res.redirect(`/update_notes/${id}`)
    }


    
})


// registration

router.get('/login',(req,res)=>{
    if(req.session.isAuth)
    {
     res.redirect('/')
    }
    else{
    res.render('login.ejs',{mess:'',tag:''})

    }
})

router.post('/login_check',async(req,res)=>{


    const {uname,pass}=req.body

    const user_record=await User.findOne({username:uname})

    console.log(req.body,user_record)

    if(user_record!==null)
    {

        const passcompare= await bcrypt.compare(pass,user_record.password)
        // console.log(passcompare)
        if(passcompare)
        {
            req.session.isAuth=true
            res.redirect('/')
        }
        else{
            res.redirect(`/login?error=${('Invalid Credentials')} `)
        }
        


    }
    else{   
                 res.redirect(`/login?error=${('Invalid Credentials')} `)

    }

    

})

router.get('/logout',(req,res)=>{
    req.session.destroy()
    res.redirect('/login')
})


// signup

router.post('/signup_check',async(req,res)=>{
    console.log(req.body)

    // const {,confirmpass}=

    const uname=req.body.uname.trim();
   const pass=req.body.pass.trim()
   const confirmpass=req.body.confirmpass.trim()

   console.log(uname.length)

    const user_present=await User.findOne({username:uname})

    if(user_present==null)
    {

        if(uname.length>=5 && pass.length>7 )
        {

               if(pass===confirmpass)
               {

                const hashpass=await bcrypt.hash(pass,10)

                const user_record=new User({username:uname,password:hashpass})

                user_record.save()

                req.session.isAuth=true

                res.redirect('/')


               }
               else{
                res.redirect('/login?error=Password is not match with confirm password!')
               }

        }
        else{
            console.log(`${uname} length: ${uname.length}, ${pass} length: ${pass.length}`)
            res.redirect('/login?error=Username/Password length is too short!')
        }

    }
    else{
        res.redirect(`/login?error=Username already exist`)

    }
})

// test url

// router.get('/test',async(req,res)=>{

//     const pass='123'

//     const hashpass= await bcrypt.hash(pass,10)

//     console.log(hashpass)


//     const user_record=  new User({username:'qazim',password:hashpass})


        
//     user_record.save()
//     // const notes_record=new Notes({title:'Note 1',desc:'djbjvbdv dbnvjdbnjvb bncjbnxjvbjdbvjdvhjhdgjh'})
//     // notes_record.save()

// })

module.exports=router